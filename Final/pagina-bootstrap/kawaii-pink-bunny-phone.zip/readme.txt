﻿=== kawaii pink bunny phone Cursor Set ===

By: goat

Download: http://www.rw-designer.com/cursor-set/kawaii-pink-bunny-phone

Author's description:

original gif found in glitter-graphics

everything except the normal select gif is edited by me

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.